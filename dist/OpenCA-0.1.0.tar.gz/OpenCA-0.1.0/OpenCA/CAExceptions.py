class SerialException(Exception):
	pass

class CNException(Exception):
	pass

class PasswordException(Exception):
	pass

class SubjectException(Exception):
	pass
